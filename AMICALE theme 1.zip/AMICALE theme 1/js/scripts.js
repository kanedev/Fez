  /*Start : Automatically start the slider */
	$('.carousel').carousel({
      interval: 4000
   });
	/*End: Automatically start the slider */
